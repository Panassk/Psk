import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.filechooser.FileSystemView;
import java.awt.*;
import java.awt.desktop.OpenFilesEvent;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.Scanner;
import java.util.logging.Logger;

public class OrderManager {
    private static JFrame frame1 = new JFrame();
    private static JMenuBar menubar = new JMenuBar();
    private static JMenu Order = new JMenu("New Order");
    private static JMenu File = new JMenu("File");
    private static JMenu Statistics = new JMenu("Statistics");
    private static JMenu About = new JMenu("About");
    private static JMenu Settings = new JMenu("System Settings");
    private static JMenuItem proceed,Open,Save,SaveAs,showstat,Info,exit;
    private static JButton Loadcsv;


    public static void main(String[] args) throws FileNotFoundException {
        //frame1.setSize(400, 350);

        frame1.setLocation(350,350);
        frame1.setSize(350,300);
        frame1.setTitle("Main menu");
        frame1.getContentPane().setBackground(Color.LIGHT_GRAY);
        frame1.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        //Building Menubar
        frame1.setJMenuBar(menubar);


        menubar.add(Order);
        //Adding new order window
        proceed = new JMenuItem("Proceed to new order");
        Order.add(proceed);

        menubar.add(File);
        //Adding options open,save,save as
        Open = new JMenuItem("Open");
        Save = new JMenuItem("Save");
        SaveAs= new JMenuItem("Save as");
        File.add(Open);
        File.add(Save);
        File.add(SaveAs);


        menubar.add(Statistics);
        //Adding statistics window
        showstat = new JMenuItem("Show Statistics");
        Statistics.add(showstat);


        menubar.add(About);
        //Adding gui info
        Info = new JMenuItem("Designer Information");
        About.add(Info);

        menubar.add(Settings);
        //Adding exit clause
        exit = new JMenuItem("Exit");
        Settings.add(exit);

        //Scanning file
        Scanner scan = new Scanner(new File("Orders.csv"));
        scan.useDelimiter(";");


        //text pane creation
        final JTextPane tp= new JTextPane();
        frame1.add(tp,BorderLayout.CENTER);

        //Load Button creation
        Loadcsv= new JButton("Read File");
        Loadcsv.setBounds(100,300,200,40);
        frame1.add(Loadcsv,BorderLayout.SOUTH);

        //Adding Scroll option
        JScrollPane Sc =new JScrollPane(tp);
        Sc.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        frame1.getContentPane().add(Sc);

        frame1.setVisible(true);



        //Exit configuration check message
        class exitaction implements ActionListener {
            public void actionPerformed(ActionEvent e) {
                int x = JOptionPane.showConfirmDialog(null,"  Εxit without saving?",
                        "close",JOptionPane.YES_NO_OPTION, JOptionPane.INFORMATION_MESSAGE);
                if(x==JOptionPane.YES_OPTION){
                    System.exit(0);
                    System.out.println("Good Bye");
                } else {
                    System.out.println("Remained Open");
                }
            }
        }
        exit.addActionListener(new exitaction());


        //Action listener in order to open new order window
        proceed.addActionListener(e ->  {
                int opt = JOptionPane.showConfirmDialog(null, "You want to proceed","Open New Order Pane",
                        JOptionPane.YES_NO_OPTION, JOptionPane.INFORMATION_MESSAGE);
                if(opt==JOptionPane.YES_OPTION) {
                    NewOrder NO = new NewOrder();
                    NO.setVisible(true);
                }else {
                    System.out.println("Declined");
                }

        });


        //Action listener in order to open statistics window
        showstat.addActionListener(e ->  {

                int opt1 =JOptionPane.showConfirmDialog(null,"Open statistics?","Open Statistics",
                        JOptionPane.YES_NO_OPTION, JOptionPane.INFORMATION_MESSAGE);
                if(opt1==JOptionPane.YES_OPTION) {
                    statistics stat = null;
                    try {
                        stat = new statistics();
                    } catch (IOException ex) {
                        ex.printStackTrace();
                    }
                    stat.setVisible(true);
                }else {
                    System.out.println("Please continue");
                }
        });

        //Action listener in order to open info window
        Info.addActionListener(e ->  {
                info i = new info();
                i.setVisible(true);

        });

        //FileChooser Open Button option
        Open.addActionListener(e -> {
            JFileChooser FC = new JFileChooser();
            FC.setCurrentDirectory(new File(System.getProperty("user.home")));
            FC.setFileFilter(new FileNameExtensionFilter("CSV","csv"));
            int res = FC.showOpenDialog(null);
            if(res==JFileChooser.APPROVE_OPTION){
                File selected= FC.getSelectedFile();
                String path= selected.getAbsolutePath();

                File MyFile= new File(path);
                try {
                    Desktop.getDesktop().open(MyFile);
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
                System.out.println("File opened Successfully");
            }

        });

        //Save option Action listener
        SaveAs.addActionListener(e -> {
            File fileName=null;
            JFileChooser FC2= new JFileChooser();
            FC2.setCurrentDirectory(new File(System.getProperty("user.home")));
            FC2.setDialogTitle("Choose a directory to save your file");
            FC2.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
            FC2.setFileFilter(new FileNameExtensionFilter("CSV","csv"));

            int res2 = FC2.showSaveDialog(null);
            if(res2==JFileChooser.APPROVE_OPTION){
                System.out.println("Your current saves is in "+ FC2.getSelectedFile());
                fileName = FC2.getSelectedFile();
                FileWriter FW= null;
                try {
                    FW = new FileWriter(fileName);
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
                try {
                    FW.write("CSV");
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }

        });

        //Load file in main frame
        Loadcsv.addActionListener(e -> {
            tp.setText("");
            String fileRes="";
            try {
                BufferedReader br= new BufferedReader(new FileReader("Orders.csv"));
                String line=null;
                while ((line = br.readLine()) !=null){
                    fileRes=fileRes+"\n"+line;
                }
            }catch (FileNotFoundException exeption){
                System.err.println("File was not found");
            }catch (IOException ioexeption){
                System.err.println("Can't read file");
            }
            tp.setText(fileRes);
        });


    }
}
