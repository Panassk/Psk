import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class info extends JFrame {
    JPanel panel;
    JLabel devinfo, devinfo2, credits, credits2, period, period2;
    JButton screen;

    public info(){
        setTitle("Developer Info");
        setSize(350,250);
        setLocation(150,200);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        //Adding information
        panel = new JPanel();
        panel.setLayout(null);
        panel.setSize(500,500);
        add(panel);

        devinfo= new JLabel("Developer Information:");
        devinfo.setBounds(10,10,150,25);
        panel.add(devinfo);

        devinfo2 = new JLabel("Panagiotis Skoufis");
        devinfo2.setBounds(200,10,150,25);
        panel.add(devinfo2);

        credits= new JLabel("Arithmos Mitrwou:");
        credits.setBounds(10,40,150,25);
        panel.add(credits);

        credits2 = new JLabel("151024");
        credits2.setBounds(200,40,150,25);
        panel.add(credits2);

        period = new JLabel("Time Period:");
        period.setBounds(10,70,150,25);
        panel.add(period);

        period2= new JLabel("25-31/5/2020");
        period2.setBounds(200,70,150,25);
        panel.add(period2);

        //Adding desktop image
        screen= new JButton("Show Screenshot");
        screen.setBounds(80,150,150,25);
        panel.add(screen);



        setVisible(true);


        screen.addActionListener(e -> {
            JFrame screenshot = new JFrame("Screenshot");
            screenshot.setSize(500,500);
            screenshot.add(new JLabel(new ImageIcon("C:\\Users\\panas\\Desktop\\Order Manager\\Backround.jpg")));
            screenshot.setVisible(true);

        });


    }
}
