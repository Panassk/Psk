import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

public class statistics extends JFrame {
    public statistics() throws IOException {
        setTitle("Statistics Explained");
        setSize(400,400);
        setLocation(200,300);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        //Creating Pane to show statistics
        JTextPane textP= new JTextPane();
        add(textP, BorderLayout.CENTER);

        int j,i=0;

        //Forwarding file contents to a list
        Scanner scan = new Scanner(new File("Orders.csv"));
        ArrayList<String> myArray = new ArrayList<String>();
        while(scan.hasNextLine()){
            myArray.add(scan.nextLine());
            myArray.add("\n");

        }
        System.out.println(myArray);

        //Create Button so as to show statistics
        JButton ShowStats = new JButton("Show Statistics");
        ShowStats.setBounds(10,10,200,25);
        add(ShowStats,BorderLayout.SOUTH);

        int sumOrder=0;
        float sumOrderCost=0;
        String maxCode,minCode;




        setVisible(true);


    }

}
