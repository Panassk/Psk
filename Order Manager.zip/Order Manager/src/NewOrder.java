import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Scanner;

public class NewOrder extends JFrame {
    private static JPanel panel;
    private static JLabel orderid, date, name, itemName, units, netprice, tax;
    private static JTextField orderText, dateText, nameText, itemText, unitsText, netpriceText, taxText;
    private static JButton Save;

    public  NewOrder(){
        setTitle("Place New Order");
        setSize(400,400);
        setLocation(800,300);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);


        //Setting panel
        panel = new JPanel();
        panel.setLayout(null);
        panel.setSize(500,300);
        add(panel);

        //Order ID input
        orderid = new JLabel("Order ID:");
        orderid.setBounds(10,10,50,25);
        panel.add(orderid);

        orderText = new JTextField();
        orderText.setBounds(150,10,165,25);
        panel.add(orderText);

        //Order Date input
        date= new JLabel("Order Date:");
        date.setBounds(10,50,100,25);
        panel.add(date);

        dateText = new JTextField();
        dateText.setBounds(150,50,165,25);
        panel.add(dateText);

        //Client Information input
        name = new JLabel("Client Name:");
        name.setBounds(10,90,100,25);
        panel.add(name);

        nameText = new JTextField();
        nameText.setBounds(150,90,165,25);
        panel.add(nameText);

        //Item information input
        itemName = new JLabel("Item Name:");
        itemName.setBounds(10,130,100,25);
        panel.add(itemName);

        itemText= new JTextField();
        itemText.setBounds(150,130,165,25);
        panel.add(itemText);

        //Units quantity input
        units = new JLabel("Units Count:");
        units.setBounds(10, 170,100,25);
        panel.add(units);

        unitsText = new JTextField();
        unitsText.setBounds(150,170,165,25);
        panel.add(unitsText);

        //Net Item price input
        netprice = new JLabel("Net Item Price:");
        netprice.setBounds(10,210,100,25);
        panel.add(netprice);

        netpriceText = new JTextField();
        netpriceText.setBounds(150,210,165,25);
        panel.add(netpriceText);

        //Tax input
        tax = new JLabel("Tax percentage:");
        tax.setBounds(10,250,100,25);
        panel.add(tax);

        taxText = new JTextField();
        taxText.setBounds(150,250,165,25);
        panel.add(taxText);

        //Adding Button to proceed with the order
        Save = new JButton("Finish your order");
        Save.setBounds(100,300,200,40);
        panel.add(Save);


        setVisible(true);



        //Action listener for order check
        Save.addActionListener(e ->  {
                //Scanner sca1 = new Scanner(System.in);
                //Scanner scan2 = new Scanner(System.in);
                //Scanner scan3= new Scanner(System.in);
                //Inputs are being placed
                String orderid= orderText.getText();
                String date = dateText.getText();
                String name = nameText.getText();
                String itemName = itemText.getText();
                String units = unitsText.getText();
                String netprice = netpriceText.getText();
                String tax = taxText.getText();
                String AM ="151024";


                //tax check
                try{
                    int tax1 = Integer.parseInt(tax);
                    if ((tax1>=0)&&(tax1<=100)) {
                        Save.setText("Order Placed!");

                        //Create Orders.csv file
                        String filepath="Orders.csv";

                        //Call method in order to save to the csv file
                        saveorders(AM,orderid,date,name,itemName,units,netprice,tax1,filepath);

                        //Closing New Order Window
                        dispose();

                    }else{
                        System.out.println("Your tax percentage is wrong please reenter");
                    }
                } catch (NumberFormatException error){
                    System.out.println("NumberFormatException"+error.getMessage());
                }

        });

    }

    public static void saveorders(String AM, String OrderId, String Date, String Name, String ItemName, String Units, String NetPrice, int Tax, String FilePath){
        try {
            //Save in csv file
            FileWriter fw = new FileWriter(FilePath,true);
            BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter wr = new PrintWriter(bw);

            //ipnuts are placed in csv file
            wr.println(AM+";"+OrderId+";"+Date+";"+Name+";"+ItemName+";"+Units+";"+NetPrice+";"+Tax);
            System.out.println("Done!");
            wr.flush();
            wr.close();

            JOptionPane.showMessageDialog(null,"Your order is completed, Thank you");


        }catch (Exception e2){
            JOptionPane.showMessageDialog(null,"Your order was not saved");
        }

    }
}
